import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:blurrycontainer/blurrycontainer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:roullet_app/Api%20Services/api_end_points.dart';
import 'package:roullet_app/Helper_Constants/Images_path.dart';
import 'package:roullet_app/Helper_Constants/colors.dart';
import 'package:roullet_app/Helper_Constants/sounds_source_path.dart';
import 'package:roullet_app/Scale%20Size/scale_size.dart';
import 'package:roullet_app/Screens/Home%20Screen/Home%20Widgets/bottom_boxes.dart';
import 'package:roullet_app/Screens/Home%20Screen/Home%20Widgets/right_bet-boxes.dart';
import 'package:roullet_app/Screens/Home%20Screen/Home%20Widgets/roulette_table.dart';
import 'package:roullet_app/Screens/Home%20Screen/Home%20Widgets/top_box_row.dart';
import 'package:roullet_app/Screens/Model/get_profile_model.dart';
import 'package:roullet_app/Widgets/coins_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../Api Services/requests.dart';
import '../Auth/login_screen.dart';
import '../Settings/about_us.dart';
import '../Settings/privacy_policy.dart';
import '../Settings/term_condition.dart';
import '../Update Password/change_password.dart';
import '../Withdrawal/my_wining_list.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {

  int? selectedCoin;
  List<int> selectedCoins = [];
  int betAmount = 0;
  bool? canceled = false;
  bool? canceledSpecificBet = false;
  bool betPlaced = false;
  bool waiting = false;
  List<int> selectedNumbers = [];
  List<int>  totalSelectedNumbers = [];
  double opacity = 0;
  late int time;
  int value = 0;
  bool isLoading = false;
  bool _animationSwitch = false;


  double coinOpacity = 1;
  double coinWidth =40;
  double coinHeight =40;
  double fromTop =25;
  double fromLeft =500;
  changeCoinPosition(){
    coinOpacity = 1;
    coinWidth =0;
    coinHeight =0;
    fromTop =15;
    fromLeft =120;
    setState(() {});

  }
  resetCoinPosition(){
    coinOpacity = 1;
    coinWidth =40;
    coinHeight =40;
    fromTop =25;
    fromLeft =500;
    setState(() {});
  }

  final TextEditingController _amountController = TextEditingController();

   late final StreamController<int> countDownStreamController;
   // late final countDownStream = countdownTimer(
   //   onChange: (int remainingSeconds) async {
   //     debugPrint("seconds remaining : $remainingSeconds");
   //     if(remainingSeconds==1){
   //            startRotation();
   //          }
   //          if(remainingSeconds%2 ==0){
   //            // playAudio(SoundSource.countDownSoundPath);
   //          }
   //        },
   //   onStart: (){},
   //   onEnd: (){}
   // ).asBroadcastStream();
  /// on select a coin
  onCoinTap(int value) {
    canceled = false;
    canceledSpecificBet = false;
    // if(seconds.value<=10){
    //   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
    //     duration: Duration(seconds: 1),
    //     content: Text("Bet Time Over"),
    //   ));
    //   return;
    // }
    if (!waiting) {
      if (!betPlaced) {
        if(selectedCoin == value){
          selectedCoin = null;
          setState(() {});
          return;
        }
        if (currentUserBalance - value >= 0) {
          _animationSwitch = !_animationSwitch;
          selectedCoin = value;
          // currentUserBalance-=value;
          playAudio(SoundSource.coinRemoveSoundPath);
          setState(() {});
          // animateOpacity();
        }
        else {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                duration: Duration(seconds: 1),
                content: Text(
                    "Your wallet balance is not Sufficient, Please add amount"),));
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text("Your bet is placed, can't increase amount now!!")));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please wait for timer to end!!")));
    }
  }

  ///start timer
  ValueNotifier<int> minutes = ValueNotifier(0);
  ValueNotifier<int> seconds = ValueNotifier(0);
  Timer? timer;
  bool soundPlayed = false;
  void startCountdown(){
    waiting = false;
    betPlaced =  false;
    canceled   = false;
    canceledSpecificBet   = false;
    seconds.value = 20;
    const oneSec = Duration(seconds: 1);// Starting from 59 seconds
    timer = Timer.periodic(
            oneSec,
            (timer) {
          if (minutes.value == 0 && seconds.value == 0) {
            seconds.value = 20;
             // startRotation();
          }
          else if (seconds.value == 0) {
              minutes.value--;
              seconds.value = 20;
            // playAudio(SoundSource.countDownSoundPath); // Play sound at every countdown
          }
          else {
        // if(seconds.value == 3){
        //    callWinningNumberApi();
        // }
            debugPrint("seconds ${seconds.value}");
        //     playAudio(SoundSource.countDownSoundPath);
            seconds.value--;
            playAudio(SoundSource.countDownSoundPath);
          }

        });
  }
  Stream<int> countdownTimer({
    VoidCallback? onStart,
    VoidCallback? onEnd,
    Function(int)? onChange,
  }) {
    const int maxCountdown = 20;
    const interval = Duration(seconds: 1);
    int currentCount =21;
    return Stream.periodic(interval, (_) {
      // final int currentCount = maxCountdown - DateTime.now().second;

      onChange?.call(currentCount);

      if (currentCount == maxCountdown) {
        onEnd?.call();
      } else if (currentCount == 0) {
        currentCount=21;
        onStart?.call();
      }
      currentCount--;
      return currentCount;
    });
  }
  Future<void> callWinningNumberApi () async{
     await getFinalNumberApi().then((value)async{
      if (!value){
          await getWinnerNumberApi();
      }
    });
  }
  late double degree;

  @override
  void dispose() {
    countDownStreamController.close();
    if (timer != null) {
      timer!.cancel();
    }
    super.dispose();
  }

  bool showSettings = false;
  ValueNotifier<double> rotationAngle = ValueNotifier(0);
  ValueNotifier<double> turns = ValueNotifier(0);
  static const rotationDuration = Duration(seconds: 12);
  Timer? rotationTimer;
  List<int> rouletteValues = [
    0,
    26,
    3,
    35,
    12,
    28,
    7,
    29,
    18,
    22,
    9,
    31,
    14,
    20,
    1,
    33,
    16,
    24,
    5,
    10,
    23,
    8,
    30,
    11,
    36,
    13,
    27,
    6,
    34,
    17,
    25,
    2,
    21,
    4,
    19,
    15,
    32
  ];
  List<String> lastTenWinningNumbers=[];
  bool showWheel = false;
  bool close = false;
  void startRotation() async {
    await callWinningNumberApi();
    // if (responseNumber != null) {
    canceled = false;
    canceledSpecificBet = false;
    showWheel = true;
    setState(() {});
    int r = finalNumber ?? 0;
    int a = rouletteValues.indexOf(r) - 2;
    if (r == 0 || r == 26) {
      a = r == 0 ? 35 : 36;
    }
    // callWinningNumberApi().then((value){
    //   r=finalNumber??0;
    //   a = rouletteValues.indexOf(r)-2;
    //   if (r == 0 || r == 26) {
    //     a = r == 0 ? 35 : 36;
    //   }
    // });
    rotationAngle.value = 0;
    rotationTimer = Timer(rotationDuration, () {});
    close = false;
    double i = 360/ 37;
    int round = 0;
    playAudio(SoundSource.spinWheelSoundPath);
    Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (rotationTimer?.isActive ?? false) {
        rotationAngle.value += i;
        turns.value -= 1.0/37;
        if (rotationAngle.value >= 360 && i == 360 / 37) {
          rotationAngle.value = 0;
        }
        if (round >= 60 &&
            round <= 120 &&
            rotationAngle.value >= (a==14?13:a)* 360 / 37 &&
            rotationAngle.value < (a + 1) * 360 / 37) {
          Timer.periodic(const Duration(milliseconds: 100), (timer) {
            i -= 180 / 37;
            if (a == 5) {
              if (i == 180 / 37) {
                rotationAngle.value = (a + 2) * 360 / 37;
                timer.cancel();
              }
            }
            if (i == 0) {
              rotationAngle.value = (a + 2) * 360 / 37;
              timer.cancel();
              // Future.delayed(const Duration(seconds: 2),(){
              //   showWheel = false;
              //   setState(() {});
              // });
            }
          });
        }
        if (i == 0) {
          timer.cancel();
          debugPrint("angle = $rotationAngle");
          debugPrint("round = $round");
          if (r == 26) {
            rotationAngle.value = 360 / 37;
          }
          winningNumber = calculateRouletteNumber(rotationAngle.value);
          setState(() {
            close = true;
            showWheel = false;
            betPlaced = true;
          });
          ApiRequests().getPrimaryWalletAmountApi(context).then((value) {
            primaryAmount = value;
          });
           Future.delayed(100.milliseconds,(){
            showWinOrLossDialog(context);
          });
          // ApiRequests().getLastTenWinnerNumbersApi(context).then((value){
          //   if(value!= null){
          //       lastTenWinningNumbers = [];
          //       for (var winner in value) {
          //         lastTenWinningNumbers.add(winner["numbers"]??"");
          //       }
          //     debugPrint("last ten winners ==> $lastTenWinningNumbers");
          //   }
          // });

        }
        round++;
      }
    });
    // }
    // else {
    //   Future.delayed(const Duration(seconds: 2), () {
    //     // betTimeCount();
    //     // startCountdown();
    //   });
    //   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
    //       content: Text("You didn't place bet, please wait for next bet")));
    // }


  }



  ///calculate Roulette number
  int? calculateRouletteNumber(rouletteAngle) {
    double section = 360 / 37;
    double halfSection = section / 2;
    double getDegree = rouletteAngle + halfSection;
    int? rouletteValue;
    for (int i = 0; i <= 37; i++) {
      if (getDegree >= i * section && getDegree <= (i + 1) * section) {
        if (i != 37) {
          rouletteValue = rouletteValues[i];
        } else {
          rouletteValue = 0;
        }
      }
    }
    debugPrint("winning number = $rouletteValue");
    return rouletteValue;
  }

  /// calculate winning amount
  calculateWinningAmount(){

  }

  /// win loss dialog
  showWinOrLossDialog(context) {
    bool win = false;
    if (totalSelectedNumbers.contains(winningNumber)) {
      win = true;
    }
    showDialog(
        context: context,
        builder: (_) {
          ApiRequests().getPrimaryWalletAmountApi(context);
          Future.delayed(const Duration(seconds: 2),(){
            Navigator.pop(context);
            setState(() {
              totalSelectedNumbers = [];
              betPlaced = false;
              currentWinningAmount = 0;
              canceled = true;
              betAmount = 0;
            });
          });
          return Dialog(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    /*\n ₹${winningAmount ?? "0"}*/
                    win ? "You Win🎉\n ₹${currentWinningAmount ?? "0"}" : "You Loss😞",
                    style: const TextStyle(
                      color: colors.primary,
                      fontSize: 20,
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Text(
                    "Winning Number: $winningNumber",
                    style: const TextStyle(
                      color: colors.secondary,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  playAudio(String sourcePath) {
    AudioPlayer().play(AssetSource(sourcePath));
  }

  late AnimationController _controller;
  late Animation<double> _animation;
  // late Animation<double> _blinkAnimation;
  @override
  void initState() {
    super.initState();
    // TODO: implement initState
    // countDownStreamController = StreamController()..addStream(countDownStream);
    startCountdown();
    getData();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    );
    _animation = Tween<double>(
      begin: 0,
      end: 2 * 3.1416,
    ).animate(_controller);
    _controller.repeat();
  }

  bool canPop = false;
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [SystemUiOverlay.bottom],
    );

    Size size = MediaQuery.of(context).size;
    double h = size.height;
    double w = size.width;
    return SafeArea(
      child: PopScope(
        canPop: canPop,
        onPopInvoked: (val) {
          showExitPopup(context);
        },
        child: Scaffold(
            body: Stack(
          children: [
            Container(
              height: h,
              width: w,
              decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [
                    colors.secondary,
                    colors.primary,
                    colors.secondary,
                  ]),
                  image: DecorationImage(
                      image: AssetImage(ImagesPath.backGroundImage),
                      fit: BoxFit.fill)),
            ),
            Positioned(
                top: 6,
                left: 6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          "Your Balance :",
                          textScaler: TextScaler.linear(
                              ScaleSize.textScaleFactor(w,
                                  maxTextScaleFactor: 2)),
                          style: const TextStyle(
                            color: colors.whiteTemp,
                          ),
                        ),
                        SizedBox(
                          width: w * 0.005,
                        ),
                        Text(
                          currentUserBalance.toString(),
                          textScaler: TextScaler.linear(
                              ScaleSize.textScaleFactor(w,
                                  maxTextScaleFactor: 2)),
                          style: const TextStyle(
                            color: colors.whiteTemp,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          "Bet Amount:",
                          textScaler: TextScaler.linear(
                              ScaleSize.textScaleFactor(w,
                                  maxTextScaleFactor: 2)),
                          style: const TextStyle(
                            color: colors.whiteTemp,
                          ),
                        ),
                        SizedBox(
                          width: w * 0.005,
                        ),
                        Text(
                          betAmount.toString(),
                          textScaler: TextScaler.linear(
                              ScaleSize.textScaleFactor(w,
                                  maxTextScaleFactor: 2)),
                          style: const TextStyle(
                            color: colors.whiteTemp,
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
            Positioned(
                top: 6,
                right: 13,
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          showSettings = !showSettings;
                          canceled = false;
                         canceledSpecificBet = false;
                        });
                      },
                      child: const Icon(
                        Icons.settings,
                        color: colors.white70,
                      ),
                    ),
                  ],
                )),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Container(
                      decoration: const BoxDecoration(boxShadow: [
                        BoxShadow(
                            color: Colors.black38,
                            blurRadius: 60,
                            spreadRadius: 12,
                            offset: Offset(1, 24))
                      ]),
                      child: AnimatedBuilder(
                          animation: _animation,
                          builder: (context, child) {
                            return Transform.rotate(
                              angle: _animation.value,
                              child: Image.asset(
                                ImagesPath.rouletteImage,
                                width: w * 0.17,
                              ),
                            );
                          })),
                ),
                // const SizedBox(height: 20,),
                // const Padding(
                //   padding:  EdgeInsets.only(left: 12),
                //   child: OddEvenBoxes(),
                // ),
                SizedBox(
                  height: h * 0.07,
                ),
              ],
            ),
            Positioned(
              left: 12,
              bottom: 16,
              child: Padding(
                padding: const EdgeInsets.only(left: 4),
                child: GestureDetector(
                    onTap: () {
                      showExitPopup(context);
                    },
                    child: Image.asset(
                      ImagesPath.exitImage,
                      width: w * 0.15,
                    )),
              ),
            ),
            // Positioned(
            //   top: 0,
            //   left: 0,
            //   child: BaseAnimationWidget(
            //     type: AnimationType.OFFSET,
            //     duration: const Duration(milliseconds: 1000),
            //     body: CoinWidget(
            //       selected: selectedCoin == 50,
            //       foreGroundColor: Colors.teal.shade700,
            //       text: "50",
            //       onTap: () {
            //         // onCoinTap(50);
            //       },
            //       // selected: selectedCoin == 50,
            //     ),
            //     offset: const Offset(255, 237),
            //     offsetType: OffsetType.UP,
            //     animationSwitch: () => _animationSwitch,
            //   ),
            // ),
            Align(
              alignment: Alignment.topCenter,
              child: Column(
                children: [
                  Stack(
                    children: [
                      TopBoxesRow(
                        h: h,
                        w: w,
                        minuteM: minutes,
                        secondS: seconds,
                      //   countDown: countdownTimer(onChange: (remainingSeconds){
                      //   // if(remainingSeconds %2 ==0){
                      //   //     playAudio(SoundSource.countDownSoundPath);
                      //   //   }
                      //     debugPrint(remainingSeconds.toString());
                      // }),
                        primaryWalletAmount: primaryAmount??"0",
                        // countDown: countDownStream,
                      ),
                      AnimatedPositioned(
                           duration: 500.milliseconds,
                        width: coinWidth,
                        height: coinHeight,
                        curve: Curves.easeIn,
                        top: fromTop,
                        left: fromLeft,
                        child: CoinWidget(
                          selected: false,
                          foreGroundColor: Colors.brown,
                          text: "",
                          onTap: () {
                            // onCoinTap(10);
                          },
                          // selected: selectedCoin == 50,
                        ),
                      )
                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      GestureDetector(
                          onTap: () {
                            canceled = false;
                            canceledSpecificBet = false;
                            if(selectedNumbers.isNotEmpty && selectedCoins.isNotEmpty){
                              ApiRequests().cancelBetApi("single");
                              if (!betPlaced) {
                                canceledSpecificBet = true;
                                betId = null;
                                winningNumber = null;
                                betAmount -= selectedCoins.last;
                                currentUserBalance = userBalance - betAmount;
                                selectedCoins.removeLast();
                                setState(() {});
                              }
                            }
                            else{
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                                  content: Text(
                                      "Please select a bet")));
                            }
                          },
                          child: BetBox(
                              text: "Cancel\n Specific Bet", w: w, h: h)),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      // BaseAnimationWidget(
                      //   type: AnimationType.OFFSET,
                      //   duration: const Duration(milliseconds: 500),
                      //   body: CoinWidget(
                      //     selected: selectedCoin == 50,
                      //     foreGroundColor: Colors.teal.shade700,
                      //     text: "50",
                      //     onTap: () {
                      //       // onCoinTap(50);
                      //     },
                      //     // selected: selectedCoin == 50,
                      //   ),
                      //   offset: const Offset(277.5, 260.5),
                      //   offsetType: OffsetType.UP,
                      //   animationSwitch: () => _animationSwitch,
                      // ),
                      CoinWidget(
                        selected: selectedCoin == 10,
                        foreGroundColor: Colors.brown,
                        text: "10",
                        onTap: () {
                          onCoinTap(10);
                        },
                        // selected: selectedCoin == 50,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 20,
                        foreGroundColor: Colors.yellow.shade700,
                        text: "20",
                        onTap: () {
                          onCoinTap(20);
                        },
                        // selected: selectedCoin == 50,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 50,
                        foreGroundColor: Colors.teal.shade700,
                        text: "50",
                        onTap: () {
                          onCoinTap(50);
                        },
                        // selected: selectedCoin == 50,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 100,
                        foreGroundColor: Colors.red.shade900,
                        text: "100",
                        onTap: () {
                          onCoinTap(100);
                        },
                        // selected: selectedCoin == 100,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 200,
                        foreGroundColor: Colors.yellow.shade900,
                        text: "200",
                        onTap: () {
                          onCoinTap(200);
                        },
                        // selected: selectedCoin == 200,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 500,
                        foreGroundColor: Colors.blueGrey.shade700,
                        text: "500",
                        onTap: () {
                          onCoinTap(500);
                        },
                        // selected: selectedCoin == 500,
                      ),
                      SizedBox(
                        width: w * 0.02,
                      ),
                      CoinWidget(
                        selected: selectedCoin == 1000,
                        foreGroundColor: Colors.pink.shade900,
                        text: "1000",
                        onTap: () {
                          onCoinTap(1000);
                        },
                        // selected: selectedCoin == 1000,
                      ),
                    ],
                  ),
                  SizedBox(
                    height: h * 0.02,
                  ),
                  RouletteTable(
                    isBetTimeOverAndBetPlaced:(seconds.value < 0,betPlaced),
                    winningAmount:(amount){
                      currentWinningAmount = amount;
                      debugPrint("amount changes $currentWinningAmount");
                    },
                    selectedCoin:  userBalance <= 0 || currentUserBalance <= 0 ?0:selectedCoin??0,
                    isClearSpecificOrReset: (canceledSpecificBet??false,canceled ?? false),
                    onChanged: (v) {
                      if (v) {
                        canceled = false;
                        canceledSpecificBet = false;
                        setState(() {});
                      }
                    },
                    selectedBetNumbers: (selectedNumbersAndCoinFromTable){
                      if (selectedNumbersAndCoinFromTable.$1.isNotEmpty &&selectedNumbersAndCoinFromTable.$2 != 0) {
                        canceled = false;
                        canceledSpecificBet = false;
                        selectedNumbers = selectedNumbersAndCoinFromTable.$1;
                        totalSelectedNumbers.addAll(selectedNumbersAndCoinFromTable.$1);
                        selectedCoins.add(selectedNumbersAndCoinFromTable.$2);
                        setState(() {});
                        betAmount += selectedCoins.last;
                        currentUserBalance = userBalance - betAmount;
                        debugPrint("selected numbers ==> ${selectedNumbersAndCoinFromTable.$1}\n"
                            "selected coins ==> $selectedCoins");


                      }
                    },
                    winningNumber: winningNumber,
                    idChanged: (id) {
                      betId = id;
                      debugPrint("bet id = $betId");
                      if(betId != null && selectedNumbers.isNotEmpty && selectedCoins.isNotEmpty){
                        ApiRequests().placeBetApi(selectedCoins.last, betId, selectedNumbers, context);
                      }
                    },
                  ),
                  SizedBox(
                    height: h * 0.03,
                  ),
                  BottomBoxes(
                    onMove: () async {
                      canceled = false;
                      canceledSpecificBet = false;

                      // await callWinningNumberApi();
                      startRotation();
                      // if (betAmount > 0 && !betPlaced) {
                      //   if (betId != null) {
                      //     betPlaced = true;
                      //     ApiRequests apiRequests = ApiRequests();
                      //     await apiRequests
                      //         .placeBetApi(
                      //             betAmount, betId, selectedNumbers, context)
                      //         .then((value) {
                      //       getResultApi();
                      //     });
                      //   } else {
                      //     ScaffoldMessenger.of(context).showSnackBar(
                      //         const SnackBar(
                      //             content:
                      //                 Text("Please select Bet Number or Bet")));
                      //   }
                      // }
                      // else if (selectedCoin != null &&
                      //     betAmount != 0 &&
                      //     !betPlaced) {
                      //   ScaffoldMessenger.of(context).showSnackBar(
                      //       const SnackBar(
                      //           content:
                      //               Text("Please select Bet Number or Bet")));
                      // } else if (betPlaced) {
                      //   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      //       content: Text(
                      //           "Your Bet is placed Successfully please wait!!")));
                      // }
                    },
                    onTake: () async {
                      changeCoinPosition();
                      // if(primaryAmount != null && primaryAmount != '0'){
                      //   setState(() {
                      //     canceled = false;
                      //     canceledSpecificBet = false;
                      //     isLoading = true;
                      //   });
                      //   // ApiRequests().showLoader(context);
                      //   await ApiRequests().addToWalletAmountApi(context);
                      //   await getData();
                      // }
                      // else{
                      //   ScaffoldMessenger.of(context).showSnackBar(
                      //     const SnackBar(content: Text('No winning Amount to take')),
                      //   );
                      // }
                    },
                    onCanceled: () {
                      resetCoinPosition();
                      canceled = false;
                      canceledSpecificBet = false;
                      // if (!betPlaced) {
                      //   if(selectedCoins.isNotEmpty&&selectedNumbers.isNotEmpty ){
                      //     ApiRequests().cancelBetApi("all");
                      //     canceled = true;
                      //     betId = null;
                      //     winningNumber = null;
                      //     betAmount = 0 ;
                      //     currentUserBalance =userBalance;
                      //     selectedCoins =[];
                      //     selectedNumbers=[];
                      //     setState(() {});
                      //   }else{
                      //     ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      //         content: Text(
                      //             "Please select a bet")));
                      //   }
                      // } else {
                      //   ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      //       content: Text(
                      //           "Your Bet is placed Successfully, can't cancel this now")));
                      // }
                    },
                  )
                ],
              ),
            ),
            // Positioned(
            //   top: h*0.4,
            //     left: w*0.085,
            //     child: Opacity(
            //       opacity: opacity,
            //       child: Text(
            //         opacity !=0 && selectedCoin != null? lastCoin != null?"+$lastCoin":"-$selectedCoin":"",
            //         textScaler: TextScaler.linear(ScaleSize.textScaleFactor(w,maxTextScaleFactor: 3.5)),
            //         style: const TextStyle(
            //           color: colors.whiteTemp,
            //           fontWeight: FontWeight.bold,
            //         ),
            //       ),
            //     )),
            showWheel
                ? Align(
                    alignment: Alignment.center,
                    child: Stack(
                      children: [
                        BlurryContainer(
                          blur: 2,
                          height: h,
                          width: w,
                          elevation: 0,
                          child: Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.all(20),
                            child: Stack(
                                alignment: Alignment.topCenter,
                                children: [
                                  ValueListenableBuilder(
                                    valueListenable: turns,

                                    builder: (_,turnsValue, child){
                                      return  AnimatedRotation(
                                        turns: turnsValue,
                                        duration: 12.seconds,
                                        child: Image.asset(
                                          ImagesPath.rouletteImage,
                                          scale: 1,
                                        ),
                                      );
                                    },
                                  ),
                              Align(
                                alignment: Alignment.center,
                                child: ValueListenableBuilder(
                                    valueListenable: rotationAngle,
                                    builder: (
                                      context,
                                      rotationAngleValue,
                                      child,
                                    ) {
                                      return Stack(
                                        alignment: Alignment.center,
                                        children: [
                                          // Transform.rotate(
                                          //   angle: -(rotationAngleValue *
                                          //       3.14 /
                                          //       550),
                                          //   child: Image.asset(
                                          //     ImagesPath.rouletteImage,
                                          //     scale: 1,
                                          //   ),
                                          // ),
                                          Transform.rotate(
                                            angle: rotationAngleValue *
                                                3.14 /
                                                180,
                                            // Convert degrees to radians
                                            child: Image.asset(
                                              ImagesPath.rouletteCenterImage,
                                              scale:2.28,
                                            ),
                                          ),
                                        ],
                                      );
                                    }),
                              ),

                              const Icon(
                                  Icons.place,
                                  size: 30,
                                  color: colors.yellow)
                            ]),
                          ),
                        ),
                        close
                            ? Positioned(
                                right: 12,
                                top: 12,
                                child: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        canceled = false;
                                        canceledSpecificBet = false;
                                        showWheel = !showWheel;
                                      });
                                      refresh();
                                    },
                                    icon: const Icon(
                                      Icons.close,
                                      color: colors.grad2Color,
                                    )))
                            : const SizedBox.shrink()
                      ],
                    ),
                  )
                : const SizedBox(),
            showSettings
                ? Align(
              alignment: Alignment.bottomRight,
              child: Stack(
                children: [
                  AnimatedContainer(
                    decoration: const BoxDecoration(
                        color: colors.white70,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            bottomLeft: Radius.circular(80))),
                    height: h * 0.9,
                    width: w * 0.25,
                    duration: Duration(milliseconds: 1000),
                    child: Stack(
                      alignment: Alignment.topRight,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // const SizedBox(height: 20,),
                            Container(
                              padding: const EdgeInsets.all(5),
                              color: colors.secondary,
                              child: Row(
                                children: [
                                  const CircleAvatar(
                                    radius: 20,
                                    backgroundColor: colors.whiteTemp,
                                    child: Icon(
                                      Icons.person,
                                      size: 30,
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 5,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children:  [
                                      Text("$userName",
                                          style: const TextStyle(
                                              color: colors.whiteTemp)),
                                      Text("$userEmail",
                                          style:  const TextStyle(
                                              color: colors.whiteTemp)),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>const WinningList())).then((value) {
                                  // SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]).then((value){
                                  //   refresh();
                                  // });
                                  refresh();
                                });
                                timer?.cancel();
                                showSettings=false;
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                color: colors.secondary,
                                child: const Row(
                                  children:  [
                                    Icon(
                                      Icons.wallet,
                                      color: colors.whiteTemp,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Winner Number",
                                      style: TextStyle(
                                        color: colors.whiteTemp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>const ChangePassword())).then((value) {
                                  showSettings=false;
                                  SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]).then((value){
                                    refresh();
                                  });
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                color: colors.secondary,
                                child: Row(
                                  children: const [
                                    Icon(
                                      Icons.lock_outlined,
                                      color: colors.whiteTemp,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Change Password",
                                      style: TextStyle(
                                        color: colors.whiteTemp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),

                            InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>const PrivacyPolicy())).then((value) {
                                  showSettings=false;
                                  SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]).then((value){
                                    refresh();
                                  });
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                color: colors.secondary,
                                child: Row(
                                  children: const [
                                    Icon(
                                      Icons.settings,
                                      color: colors.whiteTemp,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Privacy Policy",
                                      style: TextStyle(
                                        color: colors.whiteTemp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),

                            InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>const TermAndCondition())).then((value) {
                                  showSettings=false;
                                  SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]).then((value){
                                    refresh();
                                  });
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                color: colors.secondary,
                                child: Row(
                                  children: const [
                                    Icon(
                                      Icons.settings,
                                      color: colors.whiteTemp,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Term & Conditions",
                                      style: TextStyle(
                                        color: colors.whiteTemp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>const AboutUs())).then((value) {
                                  showSettings=false;
                                  SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]).then((value){
                                    refresh();
                                  });
                                });
                              },
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                color: colors.secondary,
                                child: const Row(
                                  children:  [
                                    Icon(
                                      Icons.settings,
                                      color: colors.whiteTemp,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "About Us",
                                      style: TextStyle(
                                        color: colors.whiteTemp,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            InkWell(
                              onTap: () {
                                showLogOutPopup(context);
                              },
                              child: Container(
                                decoration: const BoxDecoration(
                                  color: colors.secondary,

                                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(25)),

                                ),
                                padding: const EdgeInsets.all(5),
                                child: const Padding(
                                  padding:  EdgeInsets.only(left: 5),
                                  child: Row(
                                    children:  [
                                      Icon(
                                        Icons.logout_outlined,
                                        color: colors.whiteTemp,
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                        "Logout",
                                        style: TextStyle(
                                          color: colors.whiteTemp,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            )
                : const SizedBox()


          ],
        )),
      ),
    );
  }

  bool isVisible = false;

  ///store UserID
  String? userId;
  getUserId() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    userId = preferences.getString("userId");
    getPrimaryWalletApi();
  }

  String? userName, userEmail;
  double currentUserBalance = 0;
  double userBalance = 0;
  Future<void> getData() async {
    // await betTimeCount();
   // AudioController().startMusic();
    await getProfile();
      userName = getProfileModel?.data.first.username ?? "";
      userEmail = getProfileModel?.data.first.email ?? "";
      userBalance = double.parse(getProfileModel?.data.first.wallet ?? "0");
      currentUserBalance = userBalance;
      primaryAmount = await ApiRequests().getPrimaryWalletAmountApi(context);
      setState(() {});
  }

  int? winningNumber;
  int? betId;

  Future<bool> showExitPopup(context) async {
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            content: SizedBox(
              height: 90,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Do you want to exit?"),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            exit(0);
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: colors.whiteTemp),
                          child: const Text("Yes",
                              style: TextStyle(color: Colors.black)),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: colors.primary,
                        ),
                        child: const Text("No",
                            style: TextStyle(color: Colors.white)),
                      ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future<bool> showLogOutPopup(context) async {
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Colors.white30,
            content: SizedBox(
              height: 90,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Are you sure you want to logout?",
                    style: TextStyle(color: colors.whiteTemp),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            if (timer != null && timer!.isActive) {
                              timer!.cancel();
                            }
                            setLogOut();
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => const LoginScreen()));
                          },
                          style: ElevatedButton.styleFrom(
                              backgroundColor: colors.whiteTemp),
                          child: const Text("Logout",
                              style: TextStyle(color: Colors.black)),
                        ),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                          child: ElevatedButton(
                        onPressed: () {
                          debugPrint('no selected');
                          Navigator.of(context).pop();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: colors.primary,
                        ),
                        child: const Text("No",
                            style: TextStyle(color: Colors.white)),
                      ))
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  Future<bool> showWalletPopup(context) async {
    return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Colors.white30,
            content: SizedBox(
              height: 90,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 0.30,
                        height: 40,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: colors.whiteTemp,
                            boxShadow: const [
                              BoxShadow(
                                  color: colors.borderColorLight,
                                  spreadRadius: 1,
                                  blurRadius: 3)
                            ]),
                        child: TextFormField(
                          readOnly: true,
                          controller: _amountController,
                          keyboardType: TextInputType.number,
                          maxLength: 10,
                          decoration: const InputDecoration(
                              hintText: "Enter Amount",
                              hintStyle: TextStyle(fontSize: 12),
                              prefixIcon: Icon(
                                Icons.call,
                                size: 20,
                              ),
                              counterText: "",
                              contentPadding: EdgeInsets.only(top: 7),
                              border: InputBorder.none),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                    ],
                  )
                ],
              ),
            ),
          );
        });
  }

  int? finalNumber;
  Future<bool> getFinalNumberApi() async {
    debugPrint("final number api called");
    canceled = false;
canceledSpecificBet = false;
    var headers = {'Cookie': 'ci_session=d32fl5jiqq17lamd73ho05s1kmri534r'};
    var request = http.MultipartRequest(
        'GET', Uri.parse("${Endpoints.baseUrl}${Endpoints.getFinalNumber}"));
    // request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    dynamic finalResult ;
    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
       finalResult = jsonDecode(result);
       debugPrint("final number api response : $finalResult");
      if (finalResult['error'] == false) {
        // setState(() {
        //   // finalNumber = int.parse(finalResult['winning_number']);
        // });

        // debugPrint("final number:$finalNumber");
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );
      }
    } else {
        debugPrint(response.reasonPhrase);
    }
    return finalResult != null?finalResult['error']??true:true;
  }
  Future<void> getWinnerNumberApi() async {
    debugPrint("winning number api called");
    canceled = false;
    canceledSpecificBet = false;
    var headers = {'Cookie': 'ci_session=d32fl5jiqq17lamd73ho05s1kmri534r'};
    var request = http.MultipartRequest(
        'GET', Uri.parse("${Endpoints.baseUrl}${Endpoints.getWinnerNumber}"));
    // request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
      var finalResult = jsonDecode(result);
      if (finalResult['error'] == false) {
        setState(() {
          finalNumber = int.parse(finalResult['winning_number']);
        });

        debugPrint("final number:$finalNumber");
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );
      }
    } else {
      debugPrint(response.reasonPhrase);
    }
  }

  GetProfileModel? getProfileModel;
  Future<void> getProfile() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    userId = preferences.getString("userId");
    var headers = {'Cookie': 'ci_session=3s8dqkgvv46gsrpbcm2b10qpegedlr5e'};
    var request = http.MultipartRequest(
        'POST', Uri.parse('${Endpoints.baseUrl}${Endpoints.getProfile}'));
    request.fields.addAll({'user_id': userId ?? ""});
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
      var finalResult = GetProfileModel.fromJson(json.decode(result));
      setState(() {
        getProfileModel = finalResult;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text("Something went wrong!! Please logout and Login again")));
      debugPrint(response.reasonPhrase);
    }
  }

  /// primary amount api
  String? primaryAmount;
  Future<void> getPrimaryWalletApi()async {
    var headers = {
      'Cookie': 'ci_session=loqaml4ctv00b7mtrafujugbdei2j9i9'
    };
    var request = http.MultipartRequest('POST', Uri.parse('${Endpoints.baseUrl}${Endpoints.getPrimaryWallet}'));
    request.fields.addAll({
      'user_id':userId.toString()
    });
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();
    if (response.statusCode == 200) {
      var result = await response.stream.bytesToString();
      var finalResult = jsonDecode(result);
      setState(() {
        primaryAmount =  finalResult['data'];
        debugPrint("primary winning amount ==> $primaryAmount");
      });
    }
    else {
      debugPrint(response.reasonPhrase);
    }

  }

  // Timer? betTimer;
  // betTimeCount() async {
  //   waiting = true;
  //   // ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please wait for timer to end for next bet")));
  //   // _minutes = 2 - DateTime.now().minute % 3;
  //   seconds.value = 60 - DateTime.now().second;
  //   Timer.periodic(const Duration(seconds: 1), (timer) {
  //     canceled = false;
  //     canceledSpecificBet = false;
  //     if (seconds.value == 0) {
  //       setState(() {
  //         minutes.value--;
  //         seconds.value = 59;
  //       });
  //     }
  //     setState(() {
  //       seconds.value--;
  //     });
  //     if (DateTime.now().minute % 3 == 0 && DateTime.now().second == 0) {
  //       timer.cancel();
  //       setState(() {
  //         minutes.value = 1;
  //         seconds.value = 0;
  //       });
  //       // startCountdown();
  //     }
  //   });
  // }

  double winningAmount = 0;
  double? currentWinningAmount;

  refresh() async {
    betPlaced = false;
    canceled = true;
    selectedCoin = null;
    betAmount = 0;
    selectedCoins = [];
    selectedNumbers = [];
    winningNumber = null;
    finalNumber = null;
    betId = null;
    // await betTimeCount();
    // startCountdown();
    await getProfile();
  }

  setLogOut() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.setBool("isLoggedIn", false);
  }
}
