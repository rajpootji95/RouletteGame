

class SoundSource{
  static const  String numberClickSoundPath = "Sounds/ui-click-43196.mp3";
  static const  String coinSelectSoundPath = 'Sounds/coin-drop.mp3';
  static const  String coinRemoveSoundPath ='Sounds/coin-and-money-bag.mp3';
  static const  String spinWheelSoundPath ='Sounds/finalSpninnersound.mp3';
  static const  String countDownSoundPath ='Sounds/clock_ticking_natural_sound.mp3';
  static const  String bottomButtonSoundPath ='Sounds/ui-click-43196.mp3';
  static const  String tableNumberRemoveSoundPath ='Sounds/mag-remove-92075.mp3';
  static const  String addWalletMoneySoundPath ='Sounds/add_money.mp3';
}