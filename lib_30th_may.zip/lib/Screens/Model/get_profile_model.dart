class GetProfileModel {
  GetProfileModel({
    required this.error,
    required this.message,
    required this.data,
  });

  final bool? error;
  final String? message;
  final List<Datum> data;

  factory GetProfileModel.fromJson(Map<String, dynamic> json){
    return GetProfileModel(
      error: json["error"],
      message: json["message"],
      data: json["data"] == null ? [] : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
    );
  }

}

class Datum {
  Datum({
    required this.id,
    required this.username,
    required this.email,
    required this.mobile,
    required this.wallet,
    required this.password,
    required this.status,
    required this.created,
    required this.updated,
  });

  final String? id;
  final String? username;
  final String? email;
  final String? mobile;
  final String? wallet;
  final String? password;
  final String? status;
  final DateTime? created;
  final DateTime? updated;

  factory Datum.fromJson(Map<String, dynamic> json){
    return Datum(
      id: json["id"],
      username: json["username"],
      email: json["email"],
      mobile: json["mobile"],
      wallet: json["wallet"],
      password: json["password"],
      status: json["status"],
      created: DateTime.tryParse(json["created"] ?? ""),
      updated: DateTime.tryParse(json["updated"] ?? ""),
    );
  }

}
