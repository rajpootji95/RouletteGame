class CollisionDetails {
  bool isReverse = false;
  late int targetPlayerIndex, pawnIndex;
}
