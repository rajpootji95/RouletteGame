
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:roullet_app/Api%20Services/api_end_points.dart';
import 'package:roullet_app/Screens/Home%20Screen/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Screens/Model/get_withdrawal_history.dart';

class ApiRequests {
  final String baseUrl = Endpoints.baseUrl;
  final String login = Endpoints.login;
  final String sendWithDrop = Endpoints.sendWithdrawalRequest;
  final String changePassword = Endpoints.changePasswordRequest;


   String? userId;
// Get user data via email
  Future<void> getUser(String email) async {
    final response = await http.get(Uri.parse('$baseUrl/users/email/$email'));
    if (response.statusCode == 200) {
      // Handle successful response
      print(response.body);
    } else {
      // Handle error response
      print('Request failed with status: ${response.statusCode}.');
    }
  }
  // login api
   Future<void> userLogin(String mobile, String password,BuildContext context) async {
    var headers = {
      'Cookie': 'ci_session=c7797mp92d9k6gmq38epdr8hm70h9vab'
    };
    var request = http.MultipartRequest('POST', Uri.parse("$baseUrl$login"));
    request.fields.addAll({
      'mobile':mobile,
      'password':password
    });
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
       var result  = await response.stream.bytesToString();
       var finalResult  = jsonDecode(result);
       if(finalResult['error']== false){
         SharedPreferences preferences = await SharedPreferences.getInstance();
         preferences.setBool("isLoggedIn", true);
         preferences.setString("userId", finalResult['data']['id'] ?? "");
         ScaffoldMessenger.of(context).showSnackBar(
           SnackBar(content: Text('${finalResult['message']}')),

         );
         Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));

       }else{
         ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${finalResult['message']}')),
         );
       }
    }
    else {
      print(response.reasonPhrase);
    }

  }


  // change password api
  Future<void> changePasswordApi(String oldPassword, String newPassword,String confirmPassword,BuildContext context) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    userId = preferences.getString("userId");
    var headers = {
      'Cookie': 'ci_session=c7797mp92d9k6gmq38epdr8hm70h9vab'
    };
    var request = http.MultipartRequest('POST', Uri.parse("$baseUrl$changePassword"));
    request.fields.addAll({
      'user_id':userId.toString(),
      'old_password':oldPassword,
      'new_password':newPassword,
      'confirm_password':confirmPassword
    });
    print(request.fields);
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var result  = await response.stream.bytesToString();
      var finalResult  = jsonDecode(result);
      if(finalResult['error']== false){

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );
        Navigator.pop(context);
        // Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));

      }else{
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );
      }
    }
    else {
      print(response.reasonPhrase);
    }

  }
  // send_withdrawal_request api
  Future<void> sendWithdrawalRequest(String amount,accountHolderName,accountNumber,bankName,ifscCode,BuildContext context) async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    userId = preferences.getString("userId");

    var headers = {
      'Cookie': 'ci_session=c7797mp92d9k6gmq38epdr8hm70h9vab'
    };
    var request = http.MultipartRequest('POST', Uri.parse("$baseUrl$sendWithDrop"));
    request.fields.addAll({
       'user_id':userId.toString(),
       'amount':amount,
       "accountNumber":accountNumber ,
       "ifscCode": ifscCode,
       "bankName":bankName,
       "account_holder_name":accountHolderName,

    });
    print(request.fields);
    print(request);
    request.headers.addAll(headers);
    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      var result  = await response.stream.bytesToString();
      var finalResult  = jsonDecode(result);
      if(finalResult['error']== false){
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );

       // Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));

      }else{
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${finalResult['message']}')),
        );
      }
    }
    else {
      print(response.reasonPhrase);
    }

  }

// get user Data via email
  Future<Map<String, dynamic>?> checkPassword(String email) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/users/email/$email'));
      if (response.statusCode == 200) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

// get active user data via user id
  Future<Map<String, dynamic>?> checkUserActive(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/users/active/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

// create active user via user id, last active date, last active time
  Future<bool> makeUserActive(
      String userId, String lastActiveDate, String lastActiveTime) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/users/active'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'user_id': userId,
          'last_active_date': lastActiveDate,
          'last_active_time': lastActiveTime,
        }),
      );
      if (response.statusCode == 201) {
        // Handle successful response
        print(response.body);
        return true;
      } else {
        print("object");
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  // Update Active User via user id, last active date, last active time
  Future<bool> updateActiveUser(
      String userId, String lastActiveDate, String lastActiveTime) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/users/active/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'last_active_date': lastActiveDate,
          'last_active_time': lastActiveTime,
        }),
      );
      if (response.statusCode == 204) {
        // Handle successful response
        print(response.body);
        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  // Delete Active User before logout
  Future<bool> deleteActiveUser(String userId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/users/active/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 204) {
        // Handle successful response
        print(response.body);
        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

// create user dashboard via user id
  Future<bool> createUserDashboard(String userId) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/users/dashboard'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'user_id': userId,
        }),
      );
      if (response.statusCode == 201) {
        // Handle successful response
        print(response.body);
        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  Future<bool> addBalanceToUserDashboard(
      String userId, String depositAmount, String newUserBalance) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/users/dashboard/deposit/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'deposit_amount': depositAmount,
          'current_balance': newUserBalance,
        }),
      );
      if (response.statusCode == 204) {
        // Handle successful response
        print(response.body);

        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  // Start new game via user id, move num, game status, last bet amount, last bet won lost
  Future<bool> startGame(String userId, String moveNum, String gameStatus,
      String last_bet_amount, String last_bet_won_lost) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/users/$userId/game'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'user_id': userId,
          'move_num': moveNum,
          'game_status': gameStatus,
          'last_bet_amount': last_bet_amount,
          'last_bet_won_lost': last_bet_won_lost,
        }),
      );
      if (response.statusCode == 201) {
        // Handle successful response
        print(response.body);
        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  // Get game of user via user id
  Future<Map<String, dynamic>?> getGameOfUser(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/users/$userId/game'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

  // Update a game via user id, move num, game status, last bet amount, last bet won lost
  Future<Map<String, dynamic>?> updateGame(
      String gameId,
      String userId,
      String gameStatus,
      String moveNum,
      String last_bet_amount,
      String last_bet_win_amount,
      String last_bet_won_lost) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/users/$userId/game'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'game_id': gameId,
          'user_id': userId,
          'game_status': gameStatus,
          'move_num': moveNum,
          'last_bet_amount': last_bet_amount,
          'last_bet_win_amount': last_bet_win_amount,
          'last_bet_won_lost': last_bet_won_lost,
        }),
      );
      if (response.statusCode == 201) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }

  // Get number of games
  Future<Map<String, dynamic>?> getNumberOfGames() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/games/number'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }


  // Update user balance
  Future<bool> updateUserBalance(String userId, String currentBalance) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/users/dashboard/balance/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{'current_balance': currentBalance}),
      );
      if (response.statusCode == 204) {
        // Handle successful response
        print(response.body);

        return true;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return false;
      }
    } catch (e) {
      print('Error: $e');
      return false;
    }
  }

  // Check role of user
  Future<Map<String, dynamic>?> checkRole(String userId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/users/role/$userId'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
      );
      if (response.statusCode == 200) {
        // Handle successful response
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return responseData;
      } else {
        // Handle error response
        print('Request failed with status: ${response.statusCode}.');
        return null;
      }
    } catch (e) {
      print('Error: $e');
      return null;
    }
  }
}
