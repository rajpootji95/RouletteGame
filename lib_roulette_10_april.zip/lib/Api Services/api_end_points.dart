class Endpoints {
  Endpoints._();
  static const String baseUrl = "https://delristech-projects.in/roulette/index.php/UserApi/";
  static const String login = "userLogin";
  static const String sendWithdrawalRequest = "send_withdrawal_request";
  static const String withdrawalHistory = "withdrawal_history";
  static const String addWallet = "add_wallet";
  static const String getProfile = "get_profile";
  static const String changePasswordRequest = "change_password";

}