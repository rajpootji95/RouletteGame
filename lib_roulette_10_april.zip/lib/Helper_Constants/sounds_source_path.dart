

class SoundSource{
  static const  String numberClickSoundPath = "Sounds/ui-click-43196.mp3";
  static const  String coinSelectSoundPath = 'Sounds/coin-drop.mp3';
  static const  String coinRemoveSoundPath ='Sounds/coin-and-money-bag.mp3';
  static const  String spinWheelSoundPath ='Sounds/finalSpninnersound.mp3';
}