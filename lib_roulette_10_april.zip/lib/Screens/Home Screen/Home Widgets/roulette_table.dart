

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:roullet_app/Helper_Constants/colors.dart';
import 'package:roullet_app/Helper_Constants/sounds_source_path.dart';
import 'package:roullet_app/Scale%20Size/scale_size.dart';

class RouletteTable extends StatefulWidget {

  const RouletteTable({super.key, required this.onChanged, required this.isClear, required this.selectedCoin,});
  final Function(bool) onChanged;
  final int selectedCoin;
  final bool isClear;





  @override
  State<RouletteTable> createState() => _RouletteTableState();
}

class _RouletteTableState extends State<RouletteTable> {
  int? winningNumber ;
  int? lastWinningNumber;
  int? winningIndex;

  int selectedNumber = 1; // Initial selected number
  List<int> numberSeries = [3,6,9,12,15,18,21,24,27,30,33,36,2,5,8,11,14,17,20,23,26,29,32,35,1,4,7,10,13,16,19,22,25,28,31,34];
  List<Color> numberColors = [colors.redColor,colors.blackColor,colors.redColor,colors.redColor,colors.blackColor,colors.redColor,colors.redColor,colors.blackColor,colors.redColor,
    colors.redColor,colors.blackColor,colors.redColor,colors.blackColor,colors.redColor,colors.blackColor,colors.blackColor,colors.redColor,colors.blackColor,colors.blackColor,colors.redColor,
    colors.blackColor,colors.blackColor,colors.redColor,colors.blackColor,colors.redColor,colors.blackColor,colors.redColor,colors.blackColor,colors.blackColor,colors.redColor,
    colors.redColor,colors.blackColor,colors.redColor,colors.blackColor,colors.blackColor,colors.redColor,];

  List<bool> betOn = List.generate(12, (index) => false);

  playAudio(String sourcePath){
    AudioPlayer().play(
        AssetSource(sourcePath));
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    if(widget.isClear){
      selectedIndexes = [];
      if(betOn.contains(true)){
        for (var i = 0;i<betOn.length;i++) {
          if(betOn[i]){
            betOn[i] = false;
          }
        }
      }
      if(isZero){
        isZero = false;
      }
    }
    if(widget.selectedCoin == 0){
      selectedIndexes = [];
    }
    if(winningNumber != null){
      winningIndex = numberSeries.indexOf(winningNumber!);
    }
    Size size = MediaQuery.of(context).size;
    double w =  size.width;
    double h =  size.height;
    return SizedBox(
        width: w*0.9,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Row(
              children: [
                SizedBox(width: w*0.2,),
                GestureDetector(
                  onTap: () {
                    onSelect(zero: "0");
                    // if( selectedNumber != 0) {
                    //   playAudio(SoundSource.numberClickSoundPath);
                    // }
                    // setState(() {
                    //   selectedNumber = 0;
                    // });

                  },
                  child: Container(
                    height: h*0.27,
                    width: w*0.05,
                    decoration: BoxDecoration(
                      // color: const Color(0XFF930000),
                      border:
                      // GradientBoxBorder(
                      //     width: selectedNumber == number ?0:1.5,
                      //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                      Border.all(
                        color:
                        colors.borderColorDark, // Highlight selected number
                        width: 1,
                      ),
                      //   boxShadow: [
                      //     selectedNumber == number ?
                      //     BoxShadow(
                      //         color: Colors.orange.shade900,
                      //         blurRadius: 3,
                      //         spreadRadius: 2
                      //     ):
                      //     const BoxShadow(
                      //         color: Colors.transparent
                      //     )
                      //   ]
                    ),
                    child: Center(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Text(
                            '0', // Accessing number from numberSeries list
                            textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 3.5),

                            style: const TextStyle(
                                color: colors.borderColorDark,
                                fontFamily: "digital"
                            ),
                          ),
                          isZero || winningNumber == 0?Container(
                            height: 12,
                            decoration: const BoxDecoration(
                              // color: colors.borderColorDark,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(
                                  color: colors.borderColorLight,
                                  blurRadius: 10,
                                  spreadRadius: 5,
                                )]
                            ),
                          ):const SizedBox()
                        ],
                      ),
                    ),
                  ),
                ),
                // Column(
                //   children: [
                //     GestureDetector(
                //       onTap: () {
                //         if( selectedNumber != 0) {
                //           playAudio(SoundSource.numberClickSoundPath);
                //         }
                //         setState(() {
                //           selectedNumber = 0;
                //         });
                //
                //       },
                //       child: Container(
                //         height: 42,
                //         width:28 ,
                //         decoration: BoxDecoration(
                //           // color: const Color(0XFF930000),
                //           border:
                //           // GradientBoxBorder(
                //           //     width: selectedNumber == number ?0:1.5,
                //           //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                //           Border.all(
                //             color:
                //             colors.borderColorDark, // Highlight selected number
                //             width: 1,
                //           ),
                //           //   boxShadow: [
                //           //     selectedNumber == number ?
                //           //     BoxShadow(
                //           //         color: Colors.orange.shade900,
                //           //         blurRadius: 3,
                //           //         spreadRadius: 2
                //           //     ):
                //           //     const BoxShadow(
                //           //         color: Colors.transparent
                //           //     )
                //           //   ]
                //         ),
                //         child: Center(
                //           child: Text(
                //             '0', // Accessing number from numberSeries list
                //             textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                //             style: TextStyle(
                //                 color: colors.borderColorDark,
                //                 fontFamily: "digital"
                //             ),
                //           ),
                //         ),
                //       ),
                //     ),
                //     GestureDetector(
                //       onTap: () {
                //         // if( selectedNumber != number) {
                //         //   playAudio(SoundSource.numberClickSoundPath);
                //         // }
                //         // setState(() {
                //         //   selectedNumber = number;
                //         // });
                //
                //       },
                //       child: Container(
                //         height: 42,
                //         width:28 ,
                //         decoration: BoxDecoration(
                //           // color: const Color(0XFF930000),
                //           border:
                //           // GradientBoxBorder(
                //           //     width: selectedNumber == number ?0:1.5,
                //           //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                //           Border.all(
                //             color:
                //             colors.borderColorDark, // Highlight selected number
                //             width: 1,
                //           ),
                //           //   boxShadow: [
                //           //     selectedNumber == number ?
                //           //     BoxShadow(
                //           //         color: Colors.orange.shade900,
                //           //         blurRadius: 3,
                //           //         spreadRadius: 2
                //           //     ):
                //           //     const BoxShadow(
                //           //         color: Colors.transparent
                //           //     )
                //           //   ]
                //         ),
                //         child: Center(
                //           child: Text(
                //             '00', // Accessing number from numberSeries list
                //             textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                //             style: TextStyle(
                //                 color: colors.borderColorDark,
                //                 fontFamily: "digital"
                //             ),
                //           ),
                //         ),
                //       ),
                //     ),
                //   ],
                // ),
                SizedBox(
                  width: w*0.6,
                  child: Table(
                    border: const TableBorder(
                      top: BorderSide(color: colors.borderColorDark),
                      left: BorderSide(color: colors.borderColorDark),
                      bottom: BorderSide(color: colors.borderColorDark),
                      right: BorderSide(color: colors.borderColorDark),
                      horizontalInside: BorderSide(color: colors.borderColorDark),
                      verticalInside: BorderSide(color: colors.borderColorDark),


                    ),
                    children: [
                      TableRow(
                          children: List.generate(12,
                                  (index){
                                final number = numberSeries[index];
                                return GestureDetector(
                                  onTap: () {
                                    onSelect(
                                        index: index
                                    );
                                    // if( selectedNumber != number) {
                                    //   playAudio(SoundSource.numberClickSoundPath);
                                    // }
                                    // setState(() {
                                    //   selectedNumber = number;
                                    // });

                                  },
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        height: h*0.07,
                                        margin: EdgeInsets.all(h*0.01),
                                        decoration: BoxDecoration(
                                          color: numberColors[index],
                                          shape: BoxShape.circle,
                                          // boxShadow: [
                                          //   selectedNumber == number ?
                                          //   BoxShadow(
                                          //       color: numberColors[index] == colors.redColor?colors.black54:Colors.orange.shade900,
                                          //       blurRadius: 3,
                                          //       spreadRadius: 2
                                          //   ):
                                          //   const BoxShadow(
                                          //       color: Colors.transparent
                                          //   )
                                          // ]
                                        ),
                                        child: Center(
                                          child: Text(
                                            '$number', // Accessing number from numberSeries list
                                            textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                                            style: const TextStyle(
                                                color: colors.borderColorDark,
                                                fontFamily: "digital"
                                            ),
                                          ),
                                        ),
                                      ),
                                      selectedIndexes.contains(index) || number == winningNumber?Container(
                                        height: 12,
                                        decoration: const BoxDecoration(
                                          // color: colors.borderColorDark,
                                            shape: BoxShape.circle,
                                            boxShadow: [BoxShadow(
                                              color: colors.borderColorLight,
                                              blurRadius: 10,
                                              spreadRadius: 5,
                                            )]
                                        ),
                                      ):const SizedBox()
                                    ],
                                  ),
                                );
                              })
                      ),
                      TableRow(
                          children: List.generate(12,
                                  (index){
                                final number = numberSeries[index+12];
                                return GestureDetector(
                                  onTap: () {
                                    onSelect(
                                        index: index+12
                                    );
                                    // if( selectedNumber != number) {
                                    //   playAudio(SoundSource.numberClickSoundPath);
                                    // }
                                    // setState(() {
                                    //   selectedNumber = number;
                                    // });

                                  },
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        height: h*0.07,
                                        margin: EdgeInsets.all(h*0.01),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: numberColors[index+12],
                                          //   boxShadow: [
                                          //     selectedNumber == number ?
                                          //     BoxShadow(
                                          //         color: Colors.orange.shade900,
                                          //         blurRadius: 3,
                                          //         spreadRadius: 2
                                          //     ):
                                          //     const BoxShadow(
                                          //         color: Colors.transparent
                                          //     )
                                          //   ]
                                        ),
                                        child: Center(
                                          child: Text(
                                            '$number', // Accessing number from numberSeries list
                                            textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                                            style: const TextStyle(
                                                color: colors.borderColorDark,
                                                fontFamily: "digital"
                                            ),
                                          ),
                                        ),
                                      ),
                                      selectedIndexes.contains(index+12)||number == winningNumber?Container(
                                        height: 12,
                                        decoration: const BoxDecoration(
                                          // color: colors.borderColorDark,
                                            shape: BoxShape.circle,
                                            boxShadow: [BoxShadow(
                                              color: colors.borderColorLight,
                                              blurRadius: 10,
                                              spreadRadius: 5,
                                            )]
                                        ),
                                      ):const SizedBox()
                                    ],
                                  ),
                                );
                              })
                      ),
                      TableRow(
                          children: List.generate(12,
                                  (index){
                                final number = numberSeries[index+24];
                                return GestureDetector(
                                  onTap: () {
                                    onSelect(
                                        index: index+24
                                    );
                                    // if( selectedNumber != number) {
                                    //   playAudio(SoundSource.numberClickSoundPath);
                                    // }
                                    // setState(() {
                                    //   selectedNumber = number;
                                    // });

                                  },
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        height: h*0.07,
                                        margin: EdgeInsets.all(h*0.01),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: numberColors[index+24],

                                          // boxShadow: [
                                          //   selectedIndexes.contains(index+24) ?
                                          //   BoxShadow(
                                          //       color: Colors.orange.shade900,
                                          //       blurRadius: 5,
                                          //       spreadRadius: 3
                                          //   ):
                                          //   const BoxShadow(
                                          //       color: Colors.transparent
                                          //   )
                                          // ]
                                        ),




                                        child: Center(
                                          child: Text(
                                            '$number', // Accessing number from numberSeries list
                                            textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                                            style:const  TextStyle(
                                                color: colors.borderColorDark,
                                                fontFamily: "digital"
                                            ),
                                          ),
                                        ),
                                      ),
                                      selectedIndexes.contains(index+24) || number == winningNumber?Container(
                                        height: 12,
                                        decoration: const BoxDecoration(
                                          // color: colors.borderColorDark,
                                            shape: BoxShape.circle,
                                            boxShadow: [BoxShadow(
                                              color: colors.borderColorLight,
                                              blurRadius: 10,
                                              spreadRadius: 5,
                                            )]
                                        ),
                                      ):const SizedBox()
                                    ],
                                  ),
                                );
                              })
                      ),
                    ],
                  ),
                ),
                Column(
                  children: List.generate(3,
                          (index){
                        final selectedRow = selectedIndexes.where((element) => (element < (index+1) * 12 && element >= index*12));
                        return GestureDetector(
                          onTap: () {
                            if(!betOn[index]){
                              betOn[index] = true;
                            }
                            onSelect(
                                outSideBet: index==0?"first row":
                                index==1?"second row":
                                "third row"
                            );

                          },
                          child: Container(
                            height: h*0.09,
                            width: w*0.05,
                            decoration: BoxDecoration(
                              // color: const Color(0XFF930000),
                              border:
                              // GradientBoxBorder(
                              //     width: selectedNumber == number ?0:1.5,
                              //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                              Border.all(
                                color:
                                colors.borderColorDark, // Highlight selected number
                                width: 1,
                              ),
                              //   boxShadow: [
                              //     selectedNumber == number ?
                              //     BoxShadow(
                              //         color: Colors.orange.shade900,
                              //         blurRadius: 3,
                              //         spreadRadius: 2
                              //     ):
                              //     const BoxShadow(
                              //         color: Colors.transparent
                              //     )
                              //   ]
                            ),
                            child: Center(
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Text(
                                    '2\nTo\n1', // Accessing number from numberSeries list
                                    textAlign: TextAlign.center,
                                    textScaleFactor: ScaleSize.textScaleFactor(w,maxFixFactor: 0.6,maxTextScaleFactor: 1.2),
                                    style: const TextStyle(
                                        color: colors.borderColorDark,
                                        fontFamily: "digital"
                                    ),
                                  ),
                                  (betOn[index]&&selectedRow.length == 12)
                                      ||
                                      (winningIndex != null &&  (index+1) * 12 > winningIndex! && winningIndex! >= index*12 )?
                                  Container(
                                    height: 16,
                                    width: 4,
                                    decoration: const BoxDecoration(
                                      // color: colors.borderColorDark,
                                      //   shape: BoxShape.circle,
                                        boxShadow: [BoxShadow(
                                          color: colors.borderColorLight,
                                          blurRadius: 10,
                                          spreadRadius: 7,
                                        )]
                                    ),
                                  ):const SizedBox()
                                ],
                              ),
                            ),
                          ),
                        );
                      }),
                )
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(width: w*0.2,),
                SizedBox(
                  width: w*0.6,
                  child: Table(
                    border: const TableBorder(
                      left: BorderSide(color: colors.borderColorDark),
                      bottom: BorderSide(color: colors.borderColorDark),
                      right: BorderSide(color: colors.borderColorDark),
                      verticalInside: BorderSide(color: colors.borderColorDark),


                    ),
                    children: [
                      TableRow(
                          children:
                          List.generate(3, (index){
                            return  GestureDetector(
                              onTap: () {
                                if(!betOn[index+3]){
                                  betOn[index+3] = true;
                                }
                                onSelect(
                                    outSideBet: index ==0?"first twelve":
                                    index == 1?"second twelve":
                                    "third twelve"
                                );
                              },
                              child: SizedBox(
                                height: h*0.09,
                                // decoration: BoxDecoration(
                                //   // color: const Color(0XFF930000),
                                //   border:
                                //   // GradientBoxBorder(
                                //   //     width: selectedNumber == number ?0:1.5,
                                //   //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                                //   Border.all(
                                //     color:
                                //     colors.borderColorDark, // Highlight selected number
                                //     width: 1,
                                //   ),
                                //   //   boxShadow: [
                                //   //     selectedNumber == number ?
                                //   //     BoxShadow(
                                //   //         color: Colors.orange.shade900,
                                //   //         blurRadius: 3,
                                //   //         spreadRadius: 2
                                //   //     ):
                                //   //     const BoxShadow(
                                //   //         color: Colors.transparent
                                //   //     )
                                //   //   ]
                                // ),
                                child: Center(
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Text(
                                        index ==0? '1st 12': // Accessing number from numberSeries list
                                        index ==1? '2nd 12':// Accessing number from numberSeries list
                                        '3rd 12',// Accessing number from numberSeries list
                                        textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                                        style: const TextStyle(
                                            color: colors.borderColorDark,
                                            fontFamily: "digital"
                                        ),
                                      ),
                                      (betOn[index+3]&&selectedIndexes.where((element) => (numberSeries[element] <= (index+1) * 12 && numberSeries[element] > index*12)).length == 12)
                                          ||(winningNumber != null && index*12 < winningNumber! && winningNumber! <=(index+1) * 12) ?
                                      Container(
                                        height: 12,
                                        width: 50,
                                        decoration:  BoxDecoration(
                                          // color: colors.borderColorDark,
                                          //   shape: BoxShape.circle,
                                            boxShadow: [BoxShadow(
                                              color: colors.borderColorLight.withOpacity(0.7),
                                              blurRadius: 10,
                                              spreadRadius: 5,
                                            )]
                                        ),
                                      ):const SizedBox()
                                    ],
                                  ),
                                ),
                              ),
                            );
                          })
                        //   [
                        //   ,
                        //   GestureDetector(
                        //     onTap: () {
                        //       if( selectedNumber != 100) {
                        //         playAudio(SoundSource.numberClickSoundPath);
                        //       }
                        //       setState(() {
                        //         selectedNumber = 100;
                        //       });
                        //
                        //     },
                        //     child: Container(
                        //       height: h*0.09,
                        //       // decoration: BoxDecoration(
                        //       //   // color: const Color(0XFF930000),
                        //       //   border:
                        //       //   // GradientBoxBorder(
                        //       //   //     width: selectedNumber == number ?0:1.5,
                        //       //   //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                        //       //   Border.all(
                        //       //     color:
                        //       //     colors.borderColorDark, // Highlight selected number
                        //       //     width: 1,
                        //       //   ),
                        //       //   //   boxShadow: [
                        //       //   //     selectedNumber == number ?
                        //       //   //     BoxShadow(
                        //       //   //         color: Colors.orange.shade900,
                        //       //   //         blurRadius: 3,
                        //       //   //         spreadRadius: 2
                        //       //   //     ):
                        //       //   //     const BoxShadow(
                        //       //   //         color: Colors.transparent
                        //       //   //     )
                        //       //   //   ]
                        //       // ),
                        //       child: Center(
                        //         child: Text(
                        //           '2nd 12', // Accessing number from numberSeries list
                        //           textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                        //           style: const TextStyle(
                        //               color: colors.borderColorDark,
                        //               fontFamily: "digital"
                        //           ),
                        //         ),
                        //       ),
                        //     ),
                        //   ),
                        //   GestureDetector(
                        //     onTap: () {
                        //       if( selectedNumber != 100) {
                        //         playAudio(SoundSource.numberClickSoundPath);
                        //       }
                        //       setState(() {
                        //         selectedNumber = 100;
                        //       });
                        //
                        //     },
                        //     child: Container(
                        //       height: h*0.09,
                        //       // decoration: BoxDecoration(
                        //       //   // color: const Color(0XFF930000),
                        //       //   border:
                        //       //   // GradientBoxBorder(
                        //       //   //     width: selectedNumber == number ?0:1.5,
                        //       //   //     gradient: LinearGradient(colors: [Colors.orange,colors.borderColorLight,colors.darkPinkColor,colors.borderColorLight])),
                        //       //   Border.all(
                        //       //     color:
                        //       //     colors.borderColorDark, // Highlight selected number
                        //       //     width: 1,
                        //       //   ),
                        //       //   //   boxShadow: [
                        //       //   //     selectedNumber == number ?
                        //       //   //     BoxShadow(
                        //       //   //         color: Colors.orange.shade900,
                        //       //   //         blurRadius: 3,
                        //       //   //         spreadRadius: 2
                        //       //   //     ):
                        //       //   //     const BoxShadow(
                        //       //   //         color: Colors.transparent
                        //       //   //     )
                        //       //   //   ]
                        //       // ),
                        //       child: Center(
                        //         child: Text(
                        //           '3rd 12', // Accessing number from numberSeries list
                        //           textScaleFactor: ScaleSize.textScaleFactor(w,maxTextScaleFactor: 2.5),
                        //           style: const TextStyle(
                        //               color: colors.borderColorDark,
                        //               fontFamily: "digital"
                        //           ),
                        //         ),
                        //       ),
                        //     ),
                        //   ),
                        // ]
                      )
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: h*0.02,),
            Row(
              mainAxisAlignment:  MainAxisAlignment.spaceAround,
              children: [
                SizedBox(width: w*0.18,),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[6]){
                      betOn[6] = true;
                    }
                    onSelect(outSideBet: "low");
                  },
                  h: h, w: w,
                  child:  Stack(
                    alignment: Alignment.center,
                    children: [
                      Text("1 To 18",
                        textScaleFactor: ScaleSize.textScaleFactor(w) ,
                        style:  const TextStyle(
                          color: Colors.white,
                          fontFamily: 'digital',
                          fontStyle: FontStyle.normal,
                        ),),
                      (betOn[6]&&selectedIndexes.where((element) => (numberSeries[element] <= 18)).length == 18)
                          || (winningNumber != null && winningNumber! <= 18)?
                      Container(
                        height: 6,
                        width: 48,
                        decoration:  BoxDecoration(
                          // color: colors.borderColorDark,
                          //   shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: colors.borderColorLight.withOpacity(0.8),
                              blurRadius: 10,
                              spreadRadius: 6,
                            )]
                        ),
                      ):const SizedBox()
                    ],
                  ), ),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[7]){
                      betOn[7] = true;
                    }
                    onSelect(outSideBet: "even");},
                  h: h,
                  w: w,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Text("EVEN",
                        textScaleFactor: ScaleSize.textScaleFactor(w) ,
                        style:  const TextStyle(
                          color: Colors.white,
                          fontFamily: 'digital',
                          fontStyle: FontStyle.normal,
                        ),),
                      (betOn[7]&&selectedIndexes.where((element) => (numberSeries[element] %2 == 0)).length == 18)
                          || (winningNumber != null && winningNumber! %2 ==0)?
                      Container(
                        height: 10,
                        width: 40,
                        decoration:  BoxDecoration(
                          // color: colors.borderColorDark,
                          //   shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: colors.borderColorLight.withOpacity(0.8),
                              blurRadius: 10,
                              spreadRadius: 6,
                            )]
                        ),
                      ):const SizedBox()
                    ],
                  ), ),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[8]){
                      betOn[8] = true;
                    }
                    onSelect(
                        outSideBet: "red"
                    );},
                  h: h,
                  w: w,
                  child: Container(
                    width: w*0.04,
                    height: h*0.04,
                    decoration:   BoxDecoration(
                      color: colors.redColor,
                      boxShadow: (betOn[8]&&selectedIndexes.where((element) => (numberColors[element] == colors.redColor)).length == 18)
                          || (winningIndex != null && numberColors[winningIndex!] == colors.redColor)?
                      [
                        const BoxShadow(
                            color: colors.borderColorLight,
                            blurRadius: 8,
                            spreadRadius: 4
                        )
                      ]:[],
                      borderRadius: BorderRadius.horizontal(right: Radius.circular(16),left:Radius.circular(16) ),
                    ),
                  ), ),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[9]){
                      betOn[9] = true;
                    }
                    onSelect(
                        outSideBet: "black"
                    );},
                  h: h,
                  w: w,
                  child: Container(
                    width: w*0.04,
                    height: h*0.04,
                    decoration:   BoxDecoration(
                      color: colors.blackColor,
                      boxShadow: (betOn[9]&&selectedIndexes.where((element) => (numberColors[element] == colors.blackColor)).length == 18)
                          || (winningIndex != null &&numberColors[winningIndex!] == colors.blackColor)?
                      [
                        const BoxShadow(
                            color: colors.borderColorLight,
                            blurRadius: 8,
                            spreadRadius: 4
                        )
                      ]:[],
                      borderRadius: const BorderRadius.horizontal(right: Radius.circular(16),left:Radius.circular(16) ),
                    ),
                  ), ),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[10]){
                      betOn[10] = true;
                    }
                    onSelect(outSideBet: "odd");},
                  h: h,
                  w: w,
                  child:Stack(
                    alignment: Alignment.center,
                    children: [
                      Text("ODD",
                        textScaleFactor: ScaleSize.textScaleFactor(w) ,
                        style:  const TextStyle(
                          color: Colors.white,
                          fontFamily: 'digital',
                          fontStyle: FontStyle.normal,
                        ),),
                      (betOn[10]&&selectedIndexes.where((element) => (numberSeries[element] %2 != 0)).length == 18)
                          || (winningNumber != null && winningNumber!%2 != 0)?
                      Container(
                        height: 10,
                        width: 40,
                        decoration:  BoxDecoration(
                          // color: colors.borderColorDark,
                          //   shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: colors.borderColorLight.withOpacity(0.7),
                              blurRadius: 10,
                              spreadRadius: 6,
                            )]
                        ),
                      ):const SizedBox()
                    ],
                  ), ),
                BottomTableContainer(
                  onTap: (){
                    if(!betOn[11]){
                      betOn[11] = true;
                    }
                    onSelect(outSideBet: "high");},
                  h: h,
                  w: w,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Text("19 To 36",
                        textScaleFactor: ScaleSize.textScaleFactor(w) ,
                        style:  const TextStyle(
                          color: Colors.white,
                          fontFamily: 'digital',
                          fontStyle: FontStyle.normal,
                        ),),
                      (betOn[11]&&selectedIndexes.where((element) => (numberSeries[element] > 18)).length == 18)
                          ||(winningNumber != null &&winningNumber! > 18)?
                      Container(
                        height: 6,
                        width: 48,
                        decoration:  BoxDecoration(
                          // color: colors.borderColorDark,
                          //   shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: colors.borderColorLight.withOpacity(0.8),
                              blurRadius: 10,
                              spreadRadius: 6,
                            )]
                        ),
                      ):const SizedBox()
                    ],
                  ), ),
              ],
            )
          ],
        )
    );
  }
  List<int> selectedIndexes = [];
  bool isZero = false;
  onSelect({int? index,String? outSideBet,String? insideBet,String? zero}){
    if(widget.selectedCoin != 0){
      if (widget.isClear) {
        widget.onChanged(true);
      }
      if (zero != null) {
        isZero = true; // selectedIndexes.add(38);
      }
      if (index != null) {
        if (!selectedIndexes.contains(index)) {
          selectedIndexes.add(index);
        }
      }
      if (outSideBet != null) {
        switch (outSideBet) {
          case 'first row':
            for (int i = 0; i < 12; i++) {
              if (!selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'second row':
            for (int i = 12; i < 24; i++) {
              if (!selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'third row':
            for (int i = 24; i < 36; i++) {
              if (!selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'first twelve':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] < 13 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'second twelve':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] > 12 &&
                  numberSeries[i] < 25 &&
                  !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'third twelve':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] > 24 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'low':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] < 19 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'high':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] > 18 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'even':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] % 2 == 0 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'odd':
            for (int i = 0; i < numberSeries.length; i++) {
              if (numberSeries[i] % 2 != 0 && !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'red':
            for (int i = 0; i < numberColors.length; i++) {
              if (numberColors[i] == colors.redColor &&
                  !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
          case 'black':
            for (int i = 0; i < numberColors.length; i++) {
              if (numberColors[i] == colors.blackColor &&
                  !selectedIndexes.contains(i)) {
                selectedIndexes.add(i);
              }
            }
            break;
        }
      }
      setState(() {});
    }
    else{
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Please Select Coins"),backgroundColor: colors.primary,));
    }
  }
}

class BottomTableContainer extends StatelessWidget {
  const BottomTableContainer({super.key,  required this.h, required this.w,required this.child, required this.onTap,});
  final Widget child;
  final double h;
  final double w;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: h*0.067,
        width: w*0.1,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
            color: colors.primary,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: colors.borderColorLight
            ),
            boxShadow: [
              BoxShadow(
                  color: colors.borderColorLight.withOpacity(0.5),
                  blurRadius: 5,
                  spreadRadius: 1
              )
            ]
        ),
        child: Center(
          child: child,
        ),
      ),
    );
  }


}





