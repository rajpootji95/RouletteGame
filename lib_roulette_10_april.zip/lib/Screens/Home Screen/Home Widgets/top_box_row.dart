import 'package:flutter/material.dart';
import 'package:roullet_app/Helper_Constants/Images_path.dart';
import 'package:roullet_app/Helper_Constants/colors.dart';

class TopBoxesRow extends StatelessWidget {
  int? minuteM,secondS;
   TopBoxesRow({super.key, required this.w, required this.h,this.minuteM,this.secondS});

  final double w;
  final double h ;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(ImagesPath.scoreImage,width: w*0.1,height: h*0.2,),
         SizedBox(width: w*0.06,),
        Stack(
          children: [
          Image.asset(ImagesPath.timerImage,width: w*0.1,height: h*0.2,),
           Positioned(
            top: 38,
              bottom: 0,
              left: 14,
              child:Text(
                '$minuteM:${secondS.toString().padLeft(2, '0')}',
                style: const TextStyle(
                  fontSize: 18,
                  fontFamily: 'DIGITAL',
                  fontWeight: FontWeight.normal,
                  letterSpacing: 1.5,
                  color: Colors.white,
                ),
              ),
              // Text("${minuteM}:${secondS}",style: const TextStyle(
              //   fontSize: 18,color: colors.whiteTemp,fontFamily: "DIGITAL",fontWeight: FontWeight.bold
              // ),)
           )
           ],
        ),
         SizedBox(width:  w*0.06,),
        Image.asset(ImagesPath.winnerImage,width: w*0.1,height: h*0.2,),
      ],
    );
  }
}
