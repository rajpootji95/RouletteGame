import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:roullet_app/Helper_Constants/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Helper_Constants/Images_path.dart';
import 'Home Screen/home_screen.dart';
import 'Auth/login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    checkLogIn();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
      ),
    );
    SystemChrome.setEnabledSystemUIMode(
      SystemUiMode.manual,
      overlays: [SystemUiOverlay.bottom],
    );
    Size size = MediaQuery.of(context).size;
    double h = size.height;
    double w = size.width;
    return Scaffold(
      body: Container(
          height: h,
          width: w,
          decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [
                colors.secondary,
                colors.primary,
                colors.secondary,
              ]),
              image: DecorationImage(
                  image: AssetImage(ImagesPath.backGroundImage),
                  fit: BoxFit.fill)),
          child: SizedBox(
            width: 150,
            height: 150,
            child: Image.asset(
              ImagesPath.rouletteImage,
              scale: 1.5,
            ),
          )),
    );
  }

  checkLogIn() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    bool? isLoggedIn = preferences.getBool("isLoggedIn");
    debugPrint("this is A ${isLoggedIn}");
    navigate(isLoggedIn ?? false);
  }

  navigate(isLoggedIn) {
    Future.delayed(const Duration(seconds: 2), () {
      if (isLoggedIn) {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => HomeScreen()));
      } else {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const LoginScreen()));
      }
    });
  }
}
